export const name = "Checkbox";

export const importDocs = `
import { Checkbox } from "/components/ui/checkbox"
`;

export const usageDocs = `
<Checkbox />
`;
