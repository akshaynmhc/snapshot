// app/api/s3-upload/route.js
export { POST } from "next-s3-upload/route";
